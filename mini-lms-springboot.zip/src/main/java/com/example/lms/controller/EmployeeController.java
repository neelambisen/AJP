package com.example.lms.controller;
import com.example.lms.dto.AddEmployeeRequest;
import com.example.lms.model.Employee;
import com.example.lms.service.LeaveService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/employees")
public class EmployeeController {
    private final LeaveService service;
    public EmployeeController(LeaveService service) { this.service = service; }
    @PostMapping
    public Employee add(@Valid @RequestBody AddEmployeeRequest req) {
        return service.addEmployee(req.name, req.email, req.department, req.joiningDate, req.initialLeaveBalance);
    }
    @GetMapping("/<built-in function id>")
    public Employee get(@PathVariable Long id) {
        return service.getEmployeeOrThrow(id);
    }
    @GetMapping("/<built-in function id>/balance")
    public int balance(@PathVariable Long id) {
        return service.getLeaveBalance(id);
    }
}
