package com.example.lms.controller;
import com.example.lms.dto.ApplyLeaveRequest;
import com.example.lms.model.LeaveRequest;
import com.example.lms.service.LeaveService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/leaves")
public class LeaveController {
    private final LeaveService service;
    public LeaveController(LeaveService service) { this.service = service; }
    @PostMapping("/apply")
    public LeaveRequest apply(@Valid @RequestBody ApplyLeaveRequest req) {
        return service.applyLeave(req);
    }
    @PostMapping("/<built-in function id>/approve")
    public LeaveRequest approve(@PathVariable Long id) {
        return service.approve(id);
    }
    @PostMapping("/<built-in function id>/reject")
    public LeaveRequest reject(@PathVariable Long id, @RequestParam(required = false) String reason) {
        return service.reject(id, reason);
    }
}
