package com.example.lms.repository;
import com.example.lms.model.LeaveRequest;
import com.example.lms.model.Employee;
import com.example.lms.model.LeaveStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;
public interface LeaveRequestRepository extends JpaRepository<LeaveRequest, Long> {
    List<LeaveRequest> findByEmployeeId(Long employeeId);
    @Query("SELECT lr FROM LeaveRequest lr WHERE lr.employee = :employee AND lr.status IN (:statuses) " +
           "AND NOT (lr.endDate < :startDate OR lr.startDate > :endDate)")
    List<LeaveRequest> findOverlaps(@Param("employee") Employee employee,
                                    @Param("startDate") LocalDate startDate,
                                    @Param("endDate") LocalDate endDate,
                                    @Param("statuses") List<LeaveStatus> statuses);
    @Query("SELECT COALESCE(SUM(lr.days),0) FROM LeaveRequest lr WHERE lr.employee = :employee AND lr.status = 'PENDING'")
    int sumPendingDays(@Param("employee") Employee employee);
}
