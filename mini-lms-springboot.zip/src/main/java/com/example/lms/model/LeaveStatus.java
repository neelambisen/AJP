package com.example.lms.model;
public enum LeaveStatus { PENDING, APPROVED, REJECTED }
