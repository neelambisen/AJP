package com.example.lms.service;
import com.example.lms.dto.ApplyLeaveRequest;
import com.example.lms.model.Employee;
import com.example.lms.model.LeaveRequest;
import com.example.lms.model.LeaveStatus;
import com.example.lms.repository.EmployeeRepository;
import com.example.lms.repository.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.List;
@Service
public class LeaveService {
    private final EmployeeRepository employeeRepository;
    private final LeaveRequestRepository leaveRepository;
    @Value("${lms.defaultAnnualLeaveDays:24}")
    private int defaultAnnualLeaveDays;
    public LeaveService(EmployeeRepository employeeRepository, LeaveRequestRepository leaveRepository) {
        this.employeeRepository = employeeRepository;
        this.leaveRepository = leaveRepository;
    }
    public Employee addEmployee(String name, String email, String department, LocalDate joiningDate, Integer initialBalance) {
        Employee e = new Employee(name, email, department, joiningDate, initialBalance != null ? initialBalance : defaultAnnualLeaveDays);
        return employeeRepository.save(e);
    }
    public Employee getEmployeeOrThrow(Long id) {
        return employeeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Employee not found: " + id));
    }
    public int getLeaveBalance(Long employeeId) {
        return getEmployeeOrThrow(employeeId).getAnnualLeaveBalance();
    }
    @Transactional
    public LeaveRequest applyLeave(ApplyLeaveRequest req) {
        Employee emp = getEmployeeOrThrow(req.employeeId);
        if (req.endDate.isBefore(req.startDate)) throw new IllegalArgumentException("End date before start date.");
        if (req.startDate.isBefore(emp.getJoiningDate())) throw new IllegalArgumentException("Cannot apply leave before joining date.");
        if (req.startDate.isBefore(LocalDate.now())) throw new IllegalArgumentException("Cannot apply leave in the past.");
        long days = ChronoUnit.DAYS.between(req.startDate, req.endDate) + 1;
        if (days <= 0) throw new IllegalArgumentException("Invalid days calculated.");
        if (days > 365) throw new IllegalArgumentException("Leave duration too large.");
        List<LeaveStatus> consider = Arrays.asList(LeaveStatus.PENDING, LeaveStatus.APPROVED);
        if (!leaveRepository.findOverlaps(emp, req.startDate, req.endDate, consider).isEmpty())
            throw new IllegalArgumentException("Overlapping leave exists.");
        int pendingDays = leaveRepository.sumPendingDays(emp);
        int availableForNew = emp.getAnnualLeaveBalance() - pendingDays;
        if (days > availableForNew) throw new IllegalArgumentException("Requested days exceed available balance (including pending).");
        LeaveRequest lr = new LeaveRequest(emp, req.startDate, req.endDate, req.reason, (int) days);
        return leaveRepository.save(lr);
    }
    @Transactional
    public LeaveRequest approve(Long leaveId) {
        LeaveRequest lr = leaveRepository.findById(leaveId).orElseThrow(() -> new IllegalArgumentException("Leave request not found: " + leaveId));
        if (lr.getStatus() != LeaveStatus.PENDING) throw new IllegalStateException("Only PENDING leaves can be approved.");
        Employee emp = lr.getEmployee();
        List<LeaveStatus> consider = Arrays.asList(LeaveStatus.APPROVED);
        if (!leaveRepository.findOverlaps(emp, lr.getStartDate(), lr.getEndDate(), consider).isEmpty())
            throw new IllegalArgumentException("Overlaps with an already approved leave.");
        if (lr.getDays() > emp.getAnnualLeaveBalance())
            throw new IllegalArgumentException("Insufficient balance at approval time.");
        emp.setAnnualLeaveBalance(emp.getAnnualLeaveBalance() - lr.getDays());
        lr.setStatus(LeaveStatus.APPROVED);
        employeeRepository.save(emp);
        return leaveRepository.save(lr);
    }
    @Transactional
    public LeaveRequest reject(Long leaveId, String reason) {
        LeaveRequest lr = leaveRepository.findById(leaveId).orElseThrow(() -> new IllegalArgumentException("Leave request not found: " + leaveId));
        if (lr.getStatus() != LeaveStatus.PENDING) throw new IllegalStateException("Only PENDING leaves can be rejected.");
        lr.setStatus(LeaveStatus.REJECTED);
        if (reason != null && !reason.isBlank()) {
            lr.setReason(lr.getReason() + " | Rejection: " + reason);
        }
        return leaveRepository.save(lr);
    }
}
