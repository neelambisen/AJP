package com.example.lms.dto;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
public class ApplyLeaveRequest {
    @NotNull public Long employeeId;
    @NotNull public LocalDate startDate;
    @NotNull public LocalDate endDate;
    @NotBlank public String reason;
}
