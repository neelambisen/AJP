package com.example.lms.dto;
import jakarta.validation.constraints.*;
import java.time.LocalDate;
public class AddEmployeeRequest {
    @NotBlank public String name;
    @NotBlank @Email public String email;
    @NotBlank public String department;
    @NotNull public LocalDate joiningDate;
    public Integer initialLeaveBalance;
}
